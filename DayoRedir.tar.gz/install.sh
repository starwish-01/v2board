#!/bin/bash

mkdir /opt/DayoRedir
cp config.json /opt/DayoRedir/
cp rules.json /opt/DayoRedir/
cp DayoRedir-linux-amd64 /opt/DayoRedir/
chmod +x /opt/DayoRedir/DayoRedir-linux-amd64

cat >/opt/DayoRedir/start.sh <<EOF
ulimit -n 512000
ulimit -n
./DayoRedir-linux-amd64 -config /opt/DayoRedir/config.json
EOF

cat >/lib/systemd/system/DayoRedir.service <<EOF
[Unit]
Description=Dayo Redir
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/DayoRedir
ExecStart=/bin/bash /opt/DayoRedir/start.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable DayoRedir.service
