
# Dayo Redir

## 0x00

- `config.json` 配置文件
- `rules.json` 规则文件
- `iptables.sh` 示例 `iptables` 规则
- `systemd/` 示例 `systemd` 配置文件

## 0x01 Configuration

`config.json` 文件中包含了程序运行时的必要配置，示例内容如下

````json
{
    "model": "client", //程序运行模式，可选 client/server
    "api_enabled": false, // 是否启用 API 模式
    "api_server": "http://127.0.0.1:9929", // API 服务器地址
    "api_key": "114514", // API Key
    "listen": ":9929", // API 服务器监听地址，仅 server 模式有效
    "buffer_size": 4096, // 缓存大小，单位为 bytes
    "http_enabled": true, // 是否启用 http proxy
    "http_listen": "127.0.0.1:80",
    "https_listen": "127.0.0.1:443",
    "sync_interval": 300,// 同步时间，用于部分定时任务的刷新，单位为秒
    "dns": "8.8.8.8:53",// 全局 DNS 设置
    "so_mark": 254,// socket mark，需和 iptables 内的配置保持一致，让 iptables 放行已分流的流量
    "blocked_target_ip": [], // 封锁特定的IP地址
    "rule_remarks": [ // 规则标记，用于从 api server 中拉取特定标记的规则，留空表示全部拉取
    ]
}
````

- 关于运行模式：`client` 模式下程序将会启用分流相关功能，从本地或者远端服务器读取规则，进行分流；`server` 模式下程序将关闭分流相关功能，对外提供本地规则文件，方便统一管理

## 0x02 Rules

`rules.json` 文件中包含里分流规则，示例内容如下

````json
{
    "includes": { // 用于存放规则模板，如域名/IP-CIDR，供分流规则引用
        "Netflix": { // 模板名
            "domains": [ // 域名
                "netflix.com"
            ],
            "ips": [ // IP-CIDR
                "8.41.4.0/24"
            ]
        }
    },
    "rules": [ // 分流规则
        {
            "method": "suffix",// 匹配模式，可选 suffix/full，若类型为 ip 则此项无效
            "domains": [],
            "ips": [],
            "dns": "1.1.1.1:53",// 若域名匹配该规则，则该域名通过此 DNS 解析，留空表示通过 全局DNS 解析
            "target": "",// 若 域名/IP 匹配该规则，则该请求直接转发到此IP地址
            "port_override": {// 目标端口覆盖
                "80": "8080", // 将目标端口 80 覆盖为 8080，下同
                "443": "8443"
            },
            "includes": [ // 引用规则模板，通过模板导入 域名/IP 列表
                "Netflix"
            ],
            "remark": "HK" // 规则标记，client 通过此标记获取特定的规则，留空则此规则不会被下发到客户端
        },
        {
            "method": "full",
            "domains": [],
            "ips": [],
            "dns": "",
            "target": "8.41.4.1",
            "port_override": {// 目标端口覆盖
                "80": "8080", // 将目标端口 80 覆盖为 8080，下同
                "443": "8443"
            },
            "includes": [
                "Netflix"
            ],
            "remark": "HK"
        }
    ]
}
````

- 匹配顺序：所有的规则都是自上而下进行匹配，且 `Domain` 匹配的优先于 `IP-CIDR`，域名匹配时优先返回规则预设的 `target`，如果 `target` 为空，则通过规则预设的`DNS` 解析，若规则预设的 `DNS` 为空，则通过 `全局DNS` 解析；IP匹配则根据 `redirect` 携带的原始目标地址进行 `full` 匹配
