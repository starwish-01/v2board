#!/bin/bash
#iptables -t nat -F
iptables -t nat -A OUTPUT -p tcp -j RETURN -m mark --mark 0xfe
iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDIRECT --to-ports 80
iptables -t nat -A OUTPUT -p tcp --dport 443 -j REDIRECT --to-ports 443